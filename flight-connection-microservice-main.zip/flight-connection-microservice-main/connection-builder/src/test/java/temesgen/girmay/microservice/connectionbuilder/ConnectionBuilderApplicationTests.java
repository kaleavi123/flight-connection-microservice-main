package temesgen.girmay.microservice.connectionbuilder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConnectionBuilderApplicationTests {

	@Test
	void contextLoads() {
	}

}
