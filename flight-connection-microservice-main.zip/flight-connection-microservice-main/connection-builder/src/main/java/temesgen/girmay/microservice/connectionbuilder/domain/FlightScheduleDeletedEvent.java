package temesgen.girmay.microservice.connectionbuilder.domain;

public class FlightScheduleDeletedEvent {
}
