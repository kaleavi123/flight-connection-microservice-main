package temesgen.girmay.microservice.connectionbuilder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConnectionBuilderApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConnectionBuilderApplication.class, args);
	}

}
