package temesgen.girmay.microservice.connectionbuilder.domain;

public class FlightScheduleUpdatedEvent {
}
