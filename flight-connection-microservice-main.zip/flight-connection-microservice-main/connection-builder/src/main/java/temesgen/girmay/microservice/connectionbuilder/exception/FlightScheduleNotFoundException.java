package temesgen.girmay.microservice.connectionbuilder.exception;

public class FlightScheduleNotFoundException extends RuntimeException {

    public FlightScheduleNotFoundException(String message) {
        super(message);
    }
}
