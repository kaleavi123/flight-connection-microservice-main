package temesgen.girmay.microservice.connectionbuilder.domain;

public class FlightScheduleCreatedEvent {
}
