INSERT INTO `airport` (`airport_code`, `airport_name`, `city_name`) VALUES
  ('BOM', 'Chhatrapati Shivaji Maharaj International Airport', 'Mumbai'),
  ('DXB', 'Dubai Internation Airport', 'Dubai'),
  ('JFK', 'John F. Kennedy International Airport', 'New York'),
  ('IAH', 'George Bush Intercontinental Airport', 'Houston');