export const SERVER_URL = 'http://localhost:8000';
export const AIRPORT_URL = 'master-data/airports';
export const FLIGHT_SCHEDULE_URL = 'master-data/flight-schedules'; 

export const CONNECTION_FLIGHTS = 'connection-builder/connection-flights';
